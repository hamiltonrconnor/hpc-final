# Add any `module load` or `export` commands that your code needs to
module load languages/intel/2020-u4
module load languages/gcc/9.3.0
# compile and run to this file.
